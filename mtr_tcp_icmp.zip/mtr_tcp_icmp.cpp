//
// Created by bf_zhanxiangli on 25-11-7.
// ������ICMP/TCP/UDP̽��ʵ��
//
#define _CRT_SECURE_NO_WARNINGS

#include "mtr_tcp_icmp.h"
#include <iostream>
#include <cstring>
#include <chrono>
#include <algorithm>

#ifdef _WIN32
#include <mstcpip.h>
#else
#include <errno.h>
#endif

// ==================== ���ߺ���ʵ�� ====================
namespace ProbeUtils {
    static bool network_initialized = false;

    bool initializeNetwork() {
        if (network_initialized) {
            return true;
        }

#ifdef _WIN32
        WSADATA wsaData;
        if (WSAStartup(MAKEWORD(2, 2), &wsaData) == 0) {
            network_initialized = true;
            return true;
        }
        return false;
#else
        network_initialized = true;
        return true;
#endif
    }

    void cleanupNetwork() {
        if (!network_initialized) {
            return;
        }

#ifdef _WIN32
        WSACleanup();
        network_initialized = false;
#else
        network_initialized = false;
#endif
    }

    uint16_t getCurrentProcessId() {
#ifdef _WIN32
        return static_cast<uint16_t>(GetCurrentProcessId() & 0xFFFF);
#else
        return static_cast<uint16_t>(getpid() & 0xFFFF);
#endif
    }

    uint64_t getCurrentTimestampMs() {
        auto now = std::chrono::system_clock::now();
        return std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()).count();
    }

    uint16_t calculateIcmpChecksum(const void* buffer, size_t length) {
        const uint16_t* data = static_cast<const uint16_t*>(buffer);
        const uint8_t* byte_data = static_cast<const uint8_t*>(buffer);
        uint32_t sum = 0;
        size_t count = length;

        // ����16λ�ֵĺ�
        while (count > 1) {
            sum += ntohs(*(data++));
            count -= 2;
        }

        // ���������ֽ�
        if (count == 1) {
          uint16_t ans;
          *(uint8_t*)&ans = byte_data[length - 1];

          //sum += byte_data[length - 1];
          sum += ans;
        }

        // ������λ
        while (sum >> 16) {
            sum = (sum & 0xFFFF) + (sum >> 16);
        }

        return static_cast<uint16_t>(~sum);
    }

    uint32_t ipStringToNetworkOrder(const std::string& ip_str) {
        struct in_addr addr;
        if (inet_pton(AF_INET, ip_str.c_str(), &addr) == 1) {
            return addr.s_addr;
        }
        return 0;
    }

    std::string networkOrderToIpString(uint32_t ip_addr) {
        struct in_addr addr;
        addr.s_addr = ip_addr;
        char ip_str[INET_ADDRSTRLEN];
        if (inet_ntop(AF_INET, &addr, ip_str, sizeof(ip_str))) {
            return std::string(ip_str);
        }
        return "";
    }

    std::string resolveDomainName(const std::string& hostname) {
        struct addrinfo hints, * result;
        memset(&hints, 0, sizeof(hints));
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;

        if (getaddrinfo(hostname.c_str(), nullptr, &hints, &result) == 0) {
            struct sockaddr_in* addr_in = reinterpret_cast<struct sockaddr_in*>(result->ai_addr);
            std::string ip = networkOrderToIpString(addr_in->sin_addr.s_addr);
            freeaddrinfo(result);
            return ip;
        }

        return "";
    }

    bool isValidIpAddress(const std::string& ip_str) {
        struct in_addr addr;
        return inet_pton(AF_INET, ip_str.c_str(), &addr) == 1;
    }

    void printProbeResult(const ProbeResult& result, const ProbeConfig& config) {
        std::cout << "[Probe] TTL=" << config.ttl
            << ", Seq=" << config.sequence
            << ", Protocol=" << config.protocol;

        if (result.success) {
            std::cout << " -> " << result.ip
                << " (" << result.type << ")"
                << ", Latency=" << result.latency_ms << "ms";
        }
        else {
            std::cout << " -> Timeout/Error";
        }
        std::cout << std::endl;
    }
}

// ==================== ICMP̽��ʵ�� ====================
namespace IcmpProbe {
    socket_t createSocket(int ip_version, const std::string& target_ip) {
        int family = (ip_version == 6) ? AF_INET6 : AF_INET;
        int protocol = (ip_version == 6) ? IPPROTO_ICMPV6 : IPPROTO_ICMP;

        socket_t sock = socket(family, SOCK_RAW, protocol);

#ifdef _WIN32
        if (sock == INVALID_SOCKET) {
            std::cerr << "[ICMP] Failed to create socket, error=" << WSAGetLastError()
                << " (Note: RAW socket requires administrator privileges on Windows)" << std::endl;
            return INVALID_SOCKET_VALUE;
        }

        // ���ý��ջ�������С
        int buffer_size = 256 * 1024;
        setsockopt(sock, SOL_SOCKET, SO_RCVBUF, (char*)&buffer_size, sizeof(buffer_size));
        setsockopt(sock, SOL_SOCKET, SO_SNDBUF, (char*)&buffer_size, sizeof(buffer_size));

        // ���÷�����ģʽ
        u_long mode = 1;
        ioctlsocket(sock, FIONBIO, &mode);
#else
        if (sock == -1) {
            std::cerr << "[ICMP] Failed to create socket, errno=" << errno
                << " (Note: RAW socket may require root privileges)" << std::endl;
            return INVALID_SOCKET_VALUE;
        }

        // ���÷�����ģʽ
        int flags = fcntl(sock, F_GETFL, 0);
        if (flags != -1) {
            fcntl(sock, F_SETFL, flags | O_NONBLOCK);
        }

        int buffer_size = 64 * 1024;
        setsockopt(sock, SOL_SOCKET, SO_SNDBUF, &buffer_size, sizeof(buffer_size));
        setsockopt(sock, SOL_SOCKET, SO_RCVBUF, &buffer_size, sizeof(buffer_size));
#endif

        return sock;
    }

    bool sendProbe(socket_t socket, const std::string& target, int ttl, int sequence) {
        // ����ICMP��
        IcmpPacket packet{};
        packet.type = ICMP_ECHO;
        packet.code = 0;
        packet.id = htons(ProbeUtils::getCurrentProcessId());
        packet.sequence = htons(static_cast<uint16_t>(sequence));
        packet.timestamp = ProbeUtils::getCurrentTimestampMs();
        strncpy(packet.data, "MTR Probe Packet", sizeof(packet.data) - 1);
        packet.checksum = 0;
        packet.checksum = ProbeUtils::calculateIcmpChecksum(&packet, sizeof(packet));

        // ����TTL
        int ttl_value = ttl;
#ifdef _WIN32
        if (setsockopt(socket, IPPROTO_IP, IP_TTL, reinterpret_cast<const char*>(&ttl_value), sizeof(ttl_value)) < 0) {
            std::cerr << "[ICMP] Failed to set TTL=" << ttl << ", error=" << WSAGetLastError() << std::endl;
            return false;
        }
#else
        if (setsockopt(socket, IPPROTO_IP, IP_TTL, &ttl_value, sizeof(ttl_value)) < 0) {
            std::cerr << "[ICMP] Failed to set TTL=" << ttl << ", errno=" << errno << std::endl;
            return false;
        }
#endif

        // ����Ŀ���ַ������
        struct sockaddr_in target_addr = {};
        target_addr.sin_family = AF_INET;
        if (inet_pton(AF_INET, target.c_str(), &target_addr.sin_addr) != 1) {
            std::cerr << "[ICMP] Invalid target address: " << target << std::endl;
            return false;
        }

        size_t sent = sendto(socket, reinterpret_cast<const char*>(&packet), sizeof(packet), 0,
            reinterpret_cast<struct sockaddr*>(&target_addr), sizeof(target_addr));

        if (sent != sizeof(packet)) {
#ifdef _WIN32
            std::cerr << "[ICMP] Failed to send packet, error=" << WSAGetLastError() << std::endl;
#else
            std::cerr << "[ICMP] Failed to send packet, errno=" << errno << std::endl;
#endif
            return false;
        }

        return true;
    }

    bool receiveResponse(socket_t socket, ProbeResult& result, int timeout_ms, int expected_sequence) {
        char buffer[4096];
        struct sockaddr_in from_addr;
        socklen_t from_len = sizeof(from_addr);
        memset(&from_addr, 0, sizeof(from_addr));

        // ���ý��ճ�ʱ
#ifdef _WIN32
        DWORD timeout = static_cast<DWORD>(timeout_ms);
        setsockopt(socket, SOL_SOCKET, SO_RCVTIMEO, (const char*)&timeout, sizeof(timeout));
#else
        struct timeval timeout;
        timeout.tv_sec = timeout_ms / 1000;
        timeout.tv_usec = (timeout_ms % 1000) * 1000;
        setsockopt(socket, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
#endif

        uint64_t start_time = ProbeUtils::getCurrentTimestampMs();
        uint64_t deadline = start_time + timeout_ms;

        while (true) {
            uint64_t current_time = ProbeUtils::getCurrentTimestampMs();
            if (current_time >= deadline) {
                result.success = false;
                return false;
            }

#ifdef _WIN32
            int received = recvfrom(socket, buffer, sizeof(buffer), 0,
                (struct sockaddr*)&from_addr, &from_len);
#else
            ssize_t received = recvfrom(socket, buffer, sizeof(buffer), 0,
                (struct sockaddr*)&from_addr, &from_len);
#endif

            if (received > 0) {
                uint64_t end_time = ProbeUtils::getCurrentTimestampMs();
                result.latency_ms = static_cast<double>(end_time - start_time);

                if (from_addr.sin_family == AF_INET) {
                    result.ip = ProbeUtils::networkOrderToIpString(from_addr.sin_addr.s_addr);
                }

                // ���˱��ص�ַ
                if (result.ip == "127.0.0.1" || result.ip == "0.0.0.0" || result.ip.empty()) {
                    continue;
                }

                if (parseResponse(buffer, static_cast<size_t>(received), result, expected_sequence)) {
                    result.success = true;
                    return true;
                }
            }
            else {
#ifdef _WIN32
                int error = WSAGetLastError();
                if (error == WSAETIMEDOUT || error == WSAEWOULDBLOCK) {
                    continue;
                }
                if (error == WSAEMSGSIZE) {
                    continue;  // ��̫�󣬼���������һ��
                }
#else
                if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) {
                    continue;
                }
#endif
                result.success = false;
                return false;
            }
        }
    }

    bool parseResponse(const char* buffer, size_t length, ProbeResult& result, int expected_sequence) {
        if (!buffer || length < 8) {
            return false;
        }

        // ����Ƿ������IPͷ
        bool has_outer_ip = false;
        size_t ip_header_len = 0;
        const IpHeader* ip_header = nullptr;

        if (length >= sizeof(IpHeader)) {
            ip_header = reinterpret_cast<const IpHeader*>(buffer);
            uint8_t version = (ip_header->version_ihl >> 4) & 0x0F;
            size_t tentative_len = (ip_header->version_ihl & 0x0F) * 4;
            if (version == 4 && tentative_len >= 20 && tentative_len <= length && length >= tentative_len + 8) {
                has_outer_ip = true;
                ip_header_len = tentative_len;
                result.ip = ProbeUtils::networkOrderToIpString(ip_header->src_addr);
            }
        }

        size_t icmp_offset = has_outer_ip ? ip_header_len : 0;
        if (length < icmp_offset + 8) {
            return false;
        }

        const IcmpPacket* icmp_packet = reinterpret_cast<const IcmpPacket*>(buffer + icmp_offset);
        uint16_t expected_id = htons(ProbeUtils::getCurrentProcessId());

        // ����Echo Reply
        if (icmp_packet->type == ICMP_ECHOREPLY) {
            if (icmp_packet->id == expected_id) {
                uint16_t seq = ntohs(icmp_packet->sequence);
                if (expected_sequence < 0 || seq == static_cast<uint16_t>(expected_sequence)) {
                    result.type = "echo_reply";
                    result.sequence = seq;
                    return true;
                }
            }
            return false;
        }

        // ����Time Exceeded
        if (icmp_packet->type == ICMP_TIME_EXCEEDED) {
            constexpr size_t icmp_header_size = 8;
            size_t min_length = icmp_offset + icmp_header_size + sizeof(IpHeader) + 8;

            if (length >= min_length) {
                const IpHeader* orig_ip = reinterpret_cast<const IpHeader*>(
                    buffer + icmp_offset + icmp_header_size);
                size_t orig_ip_len = (orig_ip->version_ihl & 0x0F) * 4;

                if (length >= icmp_offset + icmp_header_size + orig_ip_len + 8) {
                    if (orig_ip->protocol == IPPROTO_ICMP) {
                        const IcmpPacket* orig_icmp = reinterpret_cast<const IcmpPacket*>(
                            buffer + icmp_offset + icmp_header_size + orig_ip_len);
                        if (orig_icmp->id == expected_id) {
                            uint16_t seq = ntohs(orig_icmp->sequence);
                            if (expected_sequence < 0 || seq == static_cast<uint16_t>(expected_sequence)) {
                                result.type = "time_exceeded";
                                result.sequence = seq;
                                return true;
                            }
                        }
                    }
                }
            }
        }

        // ����Destination Unreachable
        if (icmp_packet->type == ICMP_DEST_UNREACH) {
            result.type = "dest_unreach";
            result.sequence = expected_sequence >= 0 ? expected_sequence : 0;
            return true;
        }

        return false;
    }
}

// ==================== TCP̽��ʵ�� ====================
namespace TcpProbe {
    socket_t createSocket(int ip_version) {
        int family = (ip_version == 6) ? AF_INET6 : AF_INET;
        socket_t sock = socket(family, SOCK_RAW, IPPROTO_TCP);

#ifdef _WIN32
        if (sock == INVALID_SOCKET) {
            std::cerr << "[TCP] Failed to create RAW socket, error=" << WSAGetLastError()
                << " (Note: RAW socket requires administrator privileges)" << std::endl;
            return INVALID_SOCKET_VALUE;
        }

        // ����IP_HDRINCLѡ��
        BOOL hdrincl = TRUE;
        if (setsockopt(sock, IPPROTO_IP, IP_HDRINCL, (char*)&hdrincl, sizeof(hdrincl)) != 0) {
            std::cerr << "[TCP] Failed to set IP_HDRINCL, error=" << WSAGetLastError() << std::endl;
            closesocket(sock);
            return INVALID_SOCKET_VALUE;
        }

        // ���û�������С
        int buffer_size = 128 * 1024;
        setsockopt(sock, SOL_SOCKET, SO_RCVBUF, (char*)&buffer_size, sizeof(buffer_size));
        setsockopt(sock, SOL_SOCKET, SO_SNDBUF, (char*)&buffer_size, sizeof(buffer_size));

        // ���÷�����ģʽ
        u_long mode = 1;
        ioctlsocket(sock, FIONBIO, &mode);
#else
        if (sock == -1) {
            std::cerr << "[TCP] Failed to create RAW socket, errno=" << errno
                << " (Note: RAW socket requires root privileges)" << std::endl;
            return INVALID_SOCKET_VALUE;
        }

        // ����IP_HDRINCLѡ��
        int hdrincl = 1;
        if (setsockopt(sock, IPPROTO_IP, IP_HDRINCL, &hdrincl, sizeof(hdrincl)) != 0) {
            std::cerr << "[TCP] Failed to set IP_HDRINCL, errno=" << errno << std::endl;
            close(sock);
            return INVALID_SOCKET_VALUE;
        }

        // ���û�������С
        int buffer_size = 128 * 1024;
        setsockopt(sock, SOL_SOCKET, SO_RCVBUF, &buffer_size, sizeof(buffer_size));
        setsockopt(sock, SOL_SOCKET, SO_SNDBUF, &buffer_size, sizeof(buffer_size));

        // ���÷�����ģʽ
        int flags = fcntl(sock, F_GETFL, 0);
        if (flags != -1) {
            fcntl(sock, F_SETFL, flags | O_NONBLOCK);
        }
#endif

        return sock;
    }

#ifdef WIN32
    bool sendProbe(neo::RefPtr<IRawPacketInterface> pinterface, packet::TCPIPHeader& sent, const net::InetAddress& target, const net::InetAddress& source, int ttl) {

      struct fakeheader // used to calculate the checksum
      {
        packet::FakeIPHeader fip;
        packet::TCPHeader tcp;
      };

      u_long seqNum = (rand() << 15) + rand();

      // workout checksum 
      fakeheader fh;
      fh.fip.clear();
      fh.tcp.clear();

      fh.fip.length = sizeof(packet::TCPHeader);
      fh.fip.destIP = target.getIPAddress();
      fh.fip.sourceIP = source.getIPAddress();
      fh.fip.protocol = IPPROTO_TCP;

      fh.tcp.destPort = target.getPortNumber();
      fh.tcp.sourcePort = rand() + 0x2000;
      fh.tcp.syn = 1;
      fh.tcp.seqNum = seqNum;
      fh.tcp.ackNum = 0;
      fh.tcp.dataOffset = sizeof(packet::TCPHeader) / 4;
      fh.tcp.window = 0x2000;
      fh.tcp.mssOptionKind = 2;
      fh.tcp.mssOptionLen = 4;
      fh.tcp.mssOptionVal = 1460;
      fh.tcp.optionNop1 = 1;
      fh.tcp.winScaleOptionKind = 3;
      fh.tcp.winScaleOptionLen = 3;
      fh.tcp.winScaleOptionVal = 2;
      fh.tcp.optionNop2 = 1;
      fh.tcp.optionNop3 = 1;
      fh.tcp.TCPSACKOptionKind = 4;
      fh.tcp.TCPSACKOptionLen = 2;

      fh.tcp.checksum = packet::in_cksum((u_short*)&fh, sizeof(fh));

      // create the ip& tcp header to send

      packet::TCPIPHeader h;
      h.ip.clear();
      h.tcp = fh.tcp;

      h.ip.length = 5;
      h.ip.destIP = target.getIPAddress();
      h.ip.sourceIP = source.getIPAddress();
      h.ip.protocol = IPPROTO_TCP;
      h.ip.version = 4;
      h.ip.dontFrag = 1;
      h.ip.moreFrags = 0;
      h.ip.id = (u_short)GetCurrentProcessId();
      h.ip.TTL = ttl;
      h.ip.totLength = sizeof(h);
      h.ip.headerChecksum = 0;
      h.ip.headerChecksum = packet::in_cksum((u_short*)&h.ip, sizeof(h.ip));

      sent = h;

      int result = pinterface->sendPacket((const char*)&h, sizeof(h));
      if (!result) {
#ifdef _WIN32
        std::cerr << "[TCP] Failed to send packet, error=" << WSAGetLastError() << std::endl;
#else
        std::cerr << "[TCP] Failed to send packet, errno=" << errno << std::endl;
#endif
        return false;
      }

      return true;
    }

    bool receiveResponse(neo::RefPtr<IRawPacketInterface> pinterface, packet::TCPIPHeader &sent, ProbeResult& result, int timeout_ms)
    {
      neo::TimeOut timeOutCounter(timeout_ms);

      // get respose
      neo::MemoryBlock recBuffer(0x10000);
      //ResponsePacketTypes respType = NOT_VALID;

      net::InetAddress respFrom;

      do
      {
        if (pinterface->recPacket(recBuffer, respFrom, timeOutCounter.getRemainingTime()))
        {
          result.ip = respFrom.getIPAddressAsString();

          //respType = validateResponse(h, recBuffer);
          packet::IPHeader* responseIP = (packet::IPHeader*)(recBuffer.getBlock());
          if (responseIP->protocol == IPPROTO_ICMP)
          {
            // the response is ICMP - so find out the type of the response
            packet::ICMPHeader* icmpheader = (packet::ICMPHeader*)(recBuffer.getBlock() + responseIP->getHeaderSize());

            switch (icmpheader->type)
            {
            case packet::ICMPHeader::DEST_UNREACH:
            case packet::ICMPHeader::TTL_EXPIRED:
            case packet::ICMPHeader::SOURCE_QUENCH:
            case packet::ICMPHeader::REDIRECT:
            {
              packet::ICMPErrorHeader* errorRep = (packet::ICMPErrorHeader*)icmpheader;
              packet::IPHeader* returnedIP = &(errorRep->ipHeader);

              // recover the the fist 64 bits of the original packet.
              packet::TCPHeader* returnedTCP = (packet::TCPHeader*)(recBuffer.getBlock() + responseIP->getHeaderSize() + errorRep->getHeaderSize());
              // only src port, dest port & seq num will be present in the returned packet.            

              if (sent.ip.id == returnedIP->id &&
                sent.ip.destIP == returnedIP->destIP &&
                sent.tcp.destPort == returnedTCP->destPort &&
                sent.tcp.seqNum == returnedTCP->seqNum)
              {
                // the error contained the packet we sent
                switch (icmpheader->type)
                {
                case packet::ICMPHeader::DEST_UNREACH: { 
                  result.type = "dest_unreach";
                }
                case packet::ICMPHeader::TTL_EXPIRED: { result.type = "ICMP_TTL_EXP"; }
                case packet::ICMPHeader::SOURCE_QUENCH: { result.type = "ICMP_SOURCE_QU"; }
                case packet::ICMPHeader::REDIRECT: { result.type = "ICMP_REDIRECT"; }
                }
              }
            }
            break;
            }
          }
          else if (responseIP->protocol == IPPROTO_TCP)
          {
            // the response is TCP - is it a response to what we sent.
            packet::TCPHeader* responseTCP = (packet::TCPHeader*)(recBuffer.getBlock() + responseIP->getHeaderSize());

            if (sent.ip.destIP == responseIP->sourceIP &&
              sent.ip.sourceIP == responseIP->destIP &&
              sent.tcp.destPort == responseTCP->sourcePort &&
              sent.tcp.sourcePort == responseTCP->destPort &&
              (sent.tcp.seqNum + 1) == responseTCP->ackNum)
            {
              if (responseTCP->rst)
              {
                result.latency_ms = timeOutCounter.getElapsedTime();
                result.success = true;
                result.type = "echo_reply";
                return true;
                //std::string ip;         // ��ӦIP��ַ
                //double latency_ms;      // �ӳ٣����룩
                //int sequence;           // ���к�
                //std::string type;       // ��Ӧ���ͣ�"echo_reply", "time_exceeded", "dest_unreach", "tcp_connected", etc.��
                //bool success;           // �Ƿ�ɹ�
                //
              }

              if (responseTCP->ack && responseTCP->syn) {
                result.ip = respFrom.getIPAddressAsString();
                result.latency_ms = timeOutCounter.getElapsedTime();
                result.success = true;
                result.type = "tcp_connected";
              }
            }
          }

          return false;
        }
      } while (!(result.success) && !timeOutCounter.hasTimedOut());

      result.latency_ms = timeOutCounter.getElapsedTime();
      return result.success;
    }

    
#else

    bool sendProbe(socket_t socket, const std::string& target, int ttl, int sequence, int dest_port) {
        if (socket == INVALID_SOCKET_VALUE) {
            return false;
        }


        if (setsockopt(socket, IPPROTO_IP, IP_TTL, (char*)&ttl, sizeof(ttl)) == SOCKET_ERROR) {
          std::cerr << "setsockopt(IP_TTL) failed: " << WSAGetLastError() << std::endl;
        }

        // ʹ�õ�����Դ�˿�
        uint16_t src_port = MTR_SRC_PORT_BASE + ttl * 10 + sequence;

        // ׼�����ݰ�������
        char packet[sizeof(IpHeader) + sizeof(TcpHeader)];
        memset(packet, 0, sizeof(packet));

        // ����IPͷ
        IpHeader* ip_header = reinterpret_cast<IpHeader*>(packet);
        ip_header->version_ihl = (4 << 4) | 5;
        ip_header->tos = 0;
        ip_header->total_length = htons(sizeof(IpHeader) + sizeof(TcpHeader));
        ip_header->id = htons(static_cast<uint16_t>(sequence));
        ip_header->flags_offset = 0;
        ip_header->ttl = static_cast<uint8_t>(ttl);
        ip_header->protocol = IPPROTO_TCP;
        ip_header->checksum = 0;

        // ��ȡ����IP��ַ
        struct sockaddr_in local_addr = {};
        local_addr.sin_family = AF_INET;
        local_addr.sin_addr.s_addr = INADDR_ANY;

        socket_t temp_sock = ::socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (temp_sock != INVALID_SOCKET_VALUE) {
            struct sockaddr_in temp_target = {};
            temp_target.sin_family = AF_INET;
            temp_target.sin_port = htons(53);
            inet_pton(AF_INET, target.c_str(), &temp_target.sin_addr);

            if (connect(temp_sock, (struct sockaddr*)&temp_target, sizeof(temp_target)) == 0) {
                socklen_t addr_len = sizeof(local_addr);
                getsockname(temp_sock, (struct sockaddr*)&local_addr, &addr_len);
            }
#ifdef _WIN32
            closesocket(temp_sock);
#else
            close(temp_sock);
#endif
        }

        ip_header->src_addr = local_addr.sin_addr.s_addr;

        // ����Ŀ��IP
        struct sockaddr_in target_addr = {};
        target_addr.sin_family = AF_INET;
        target_addr.sin_port = htons(dest_port);
        inet_pton(AF_INET, target.c_str(), &target_addr.sin_addr);
        ip_header->dst_addr = target_addr.sin_addr.s_addr;

        // ����IPͷУ���
        ip_header->checksum = ProbeUtils::calculateIcmpChecksum(ip_header, sizeof(IpHeader));

        // ����TCPͷ
        TcpHeader* tcp_header = reinterpret_cast<TcpHeader*>(packet + sizeof(IpHeader));
        tcp_header->src_port = htons(src_port);
        tcp_header->dst_port = htons(dest_port);
        tcp_header->seq_num = htonl(static_cast<uint32_t>(sequence));
        tcp_header->ack_num = 0;
        tcp_header->data_offset = (5 << 4);
        tcp_header->flags = TH_SYN;
        tcp_header->window = htons(65535);
        tcp_header->checksum = 0;
        tcp_header->urgent_ptr = 0;

        // ����TCPУ���
        struct {
            uint32_t src_addr;
            uint32_t dst_addr;
            uint8_t zero;
            uint8_t protocol;
            uint16_t tcp_length;
        } pseudo_header;

        pseudo_header.src_addr = ip_header->src_addr;
        pseudo_header.dst_addr = ip_header->dst_addr;
        pseudo_header.zero = 0;
        pseudo_header.protocol = IPPROTO_TCP;
        pseudo_header.tcp_length = htons(sizeof(TcpHeader));

        char checksum_buffer[sizeof(pseudo_header) + sizeof(TcpHeader)];
        memcpy(checksum_buffer, &pseudo_header, sizeof(pseudo_header));
        memcpy(checksum_buffer + sizeof(pseudo_header), tcp_header, sizeof(TcpHeader));
        tcp_header->checksum = ProbeUtils::calculateIcmpChecksum(checksum_buffer, sizeof(checksum_buffer));

        // �������ݰ�
        int result = sendto(socket, packet, sizeof(packet), 0,
            reinterpret_cast<struct sockaddr*>(&target_addr), sizeof(target_addr));

        if (result != sizeof(packet)) {
#ifdef _WIN32
            std::cerr << "[TCP] Failed to send packet, error=" << WSAGetLastError() << std::endl;
#else
            std::cerr << "[TCP] Failed to send packet, errno=" << errno << std::endl;
#endif
            return false;
        }

        return true;
    }

#endif // WIN32

    bool receiveResponse(socket_t socket, ProbeResult& result, int timeout_ms, const std::string& target_ip, int dest_port) {
        if (socket == INVALID_SOCKET_VALUE) {
            return false;
        }

        // ���socket����״̬
        int socket_error = 0;
        socklen_t error_len = sizeof(socket_error);

#ifdef _WIN32
        if (getsockopt(socket, SOL_SOCKET, SO_ERROR, (char*)&socket_error, &error_len) == 0 && socket_error != 0) {
            switch (socket_error) {
            case WSAECONNREFUSED:
                result.ip = "conn_refused";
                result.type = "tcp_conn_refused";
                result.success = true;
                return true;
            case WSAEHOSTUNREACH:
            case WSAENETUNREACH:
                result.ip = "intermediate_router";
                result.type = "tcp_unreachable";
                result.success = true;
                return true;
            case WSAETIMEDOUT:
                result.ip = "ttl_exceeded";
                result.type = "tcp_timeout";
                result.success = true;
                return true;
            }
        }
#else
        if (getsockopt(socket, SOL_SOCKET, SO_ERROR, &socket_error, &error_len) == 0 && socket_error != 0) {
            switch (socket_error) {
            case ECONNREFUSED:
                result.ip = "conn_refused";
                result.type = "tcp_conn_refused";
                result.success = true;
                return true;
            case EHOSTUNREACH:
            case ENETUNREACH:
                result.ip = "intermediate_router";
                result.type = "tcp_unreachable";
                result.success = true;
                return true;
            case ETIMEDOUT:
                result.ip = "ttl_exceeded";
                result.type = "tcp_timeout";
                result.success = true;
                return true;
            }
        }
#endif

        // ʹ��select���socket״̬
        fd_set read_fds, write_fds, error_fds;
        FD_ZERO(&read_fds);
        FD_ZERO(&write_fds);
        FD_ZERO(&error_fds);
        FD_SET(socket, &read_fds);
        FD_SET(socket, &write_fds);
        FD_SET(socket, &error_fds);

        struct timeval tv;
        tv.tv_sec = timeout_ms / 1000;
        tv.tv_usec = (timeout_ms % 1000) * 1000;

#ifdef _WIN32
        int ready = select(0, &read_fds, &write_fds, &error_fds, &tv);
#else
        int ready = select(socket + 1, &read_fds, &write_fds, &error_fds, &tv);
#endif

        if (ready > 0) {
            // ����Ƿ��д�����ӳɹ���
            if (FD_ISSET(socket, &write_fds)) {
                struct sockaddr_in peer_addr;
                socklen_t peer_len = sizeof(peer_addr);

                if (getpeername(socket, (struct sockaddr*)&peer_addr, &peer_len) == 0) {
                    std::string connected_ip = ProbeUtils::networkOrderToIpString(peer_addr.sin_addr.s_addr);
                    if (connected_ip == target_ip) {
                        result.ip = connected_ip;
                        result.type = "tcp_connected";
                        result.success = true;
                        return true;
                    }
                }
            }
        }

        result.success = false;
        return false;
    }

    bool parseIcmpResponse(const char* buffer, size_t length, ProbeResult& result, const std::string& target_ip, int dest_port) {
        if (!buffer || length < sizeof(IpHeader)) {
            return false;
        }

        const IpHeader* ip_header = reinterpret_cast<const IpHeader*>(buffer);
        uint8_t version = (ip_header->version_ihl >> 4) & 0x0F;
        if (version != 4) {
            return false;
        }

        size_t ip_header_len = (ip_header->version_ihl & 0x0F) * 4;
        if (ip_header_len < 20 || ip_header_len > length || length < ip_header_len + 8) {
            return false;
        }

        if (ip_header->protocol != IPPROTO_ICMP) {
            return false;
        }

        const IcmpPacket* icmp = reinterpret_cast<const IcmpPacket*>(buffer + ip_header_len);

        // ����Time Exceeded
        if (icmp->type == ICMP_TIME_EXCEEDED) {
            constexpr size_t icmp_header_size = 8;
            size_t min_length = ip_header_len + icmp_header_size + sizeof(IpHeader) + 8;

            if (length >= min_length) {
                const IpHeader* orig_ip = reinterpret_cast<const IpHeader*>(
                    buffer + ip_header_len + icmp_header_size);
                size_t orig_ip_len = (orig_ip->version_ihl & 0x0F) * 4;

                if (length >= ip_header_len + icmp_header_size + orig_ip_len + sizeof(TcpHeader) &&
                    orig_ip->protocol == IPPROTO_TCP) {
                    const TcpHeader* orig_tcp = reinterpret_cast<const TcpHeader*>(
                        buffer + ip_header_len + icmp_header_size + orig_ip_len);

                    uint16_t tcp_dest_port = ntohs(orig_tcp->dst_port);
                    if (tcp_dest_port == dest_port) {
                        result.type = "tcp_time_exceeded";
                        result.success = true;
                        return true;
                    }
                }
            }
        }

        return false;
    }
}

// ==================== UDP̽��ʵ�� ====================
namespace UdpProbe {
    socket_t createSocket(int ip_version) {
        int family = (ip_version == 6) ? AF_INET6 : AF_INET;
        socket_t sock = socket(family, SOCK_DGRAM, IPPROTO_UDP);

#ifdef _WIN32
        if (sock == INVALID_SOCKET) {
            std::cerr << "[UDP] Failed to create socket, error=" << WSAGetLastError() << std::endl;
            return INVALID_SOCKET_VALUE;
        }

        int buffer_size = 64 * 1024;
        setsockopt(sock, SOL_SOCKET, SO_RCVBUF, (char*)&buffer_size, sizeof(buffer_size));
        setsockopt(sock, SOL_SOCKET, SO_SNDBUF, (char*)&buffer_size, sizeof(buffer_size));

        u_long mode = 1;
        ioctlsocket(sock, FIONBIO, &mode);
#else
        if (sock == -1) {
            std::cerr << "[UDP] Failed to create socket, errno=" << errno << std::endl;
            return INVALID_SOCKET_VALUE;
        }

        int flags = fcntl(sock, F_GETFL, 0);
        if (flags != -1) {
            fcntl(sock, F_SETFL, flags | O_NONBLOCK);
        }

        int buffer_size = 64 * 1024;
        setsockopt(sock, SOL_SOCKET, SO_RCVBUF, &buffer_size, sizeof(buffer_size));
        setsockopt(sock, SOL_SOCKET, SO_SNDBUF, &buffer_size, sizeof(buffer_size));
#endif

        return sock;
    }

    bool sendProbe(socket_t socket, const std::string& target, int ttl, int sequence, int dest_port) {
        // ����UDP̽���
        UdpProbePacket packet = {};
        packet.timestamp = ProbeUtils::getCurrentTimestampMs();
        packet.sequence = htons(static_cast<uint16_t>(sequence));
        snprintf(packet.data, sizeof(packet.data), "MTR UDP Probe");

        // ����TTL
        int ttl_value = ttl;
#ifdef _WIN32
        if (setsockopt(socket, IPPROTO_IP, IP_TTL, reinterpret_cast<const char*>(&ttl_value), sizeof(ttl_value)) < 0) {
            std::cerr << "[UDP] Failed to set TTL, error=" << WSAGetLastError() << std::endl;
            return false;
        }
#else
        if (setsockopt(socket, IPPROTO_IP, IP_TTL, &ttl_value, sizeof(ttl_value)) < 0) {
            std::cerr << "[UDP] Failed to set TTL, errno=" << errno << std::endl;
            return false;
        }
#endif

        // ����Ŀ���ַ������
        struct sockaddr_in target_addr = {};
        target_addr.sin_family = AF_INET;
        target_addr.sin_port = htons(dest_port);
        if (inet_pton(AF_INET, target.c_str(), &target_addr.sin_addr) != 1) {
            std::cerr << "[UDP] Invalid target address: " << target << std::endl;
            return false;
        }

        const char* data_to_send = reinterpret_cast<const char*>(&packet.timestamp);
        size_t data_size = sizeof(packet.timestamp) + sizeof(packet.sequence) + sizeof(packet.data);

        size_t sent = sendto(socket, data_to_send, data_size, 0,
            reinterpret_cast<struct sockaddr*>(&target_addr), sizeof(target_addr));

        if (sent < 0) {
#ifdef _WIN32
            std::cerr << "[UDP] Failed to send packet, error=" << WSAGetLastError() << std::endl;
#else
            std::cerr << "[UDP] Failed to send packet, errno=" << errno << std::endl;
#endif
            return false;
        }

        return true;
    }

    bool receiveResponse(socket_t icmp_socket, ProbeResult& result, int timeout_ms, int expected_sequence) {
        // UDP̽��ͨ��ICMP socket����ICMP������Ϣ
        char buffer[1024];
        struct sockaddr_in from_addr;
        socklen_t from_len = sizeof(from_addr);
        memset(&from_addr, 0, sizeof(from_addr));

        // ���ó�ʱ
#ifdef _WIN32
        DWORD timeout = static_cast<DWORD>(timeout_ms);
        setsockopt(icmp_socket, SOL_SOCKET, SO_RCVTIMEO, (const char*)&timeout, sizeof(timeout));
#else
        struct timeval timeout;
        timeout.tv_sec = timeout_ms / 1000;
        timeout.tv_usec = (timeout_ms % 1000) * 1000;
        setsockopt(icmp_socket, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
#endif

        uint64_t start_time = ProbeUtils::getCurrentTimestampMs();

#ifdef _WIN32
        int received = recvfrom(icmp_socket, buffer, sizeof(buffer), 0,
            (struct sockaddr*)&from_addr, &from_len);
#else
        ssize_t received = recvfrom(icmp_socket, buffer, sizeof(buffer), 0,
            (struct sockaddr*)&from_addr, &from_len);
#endif

        if (received > 0) {
            uint64_t end_time = ProbeUtils::getCurrentTimestampMs();
            result.latency_ms = static_cast<double>(end_time - start_time);
            result.ip = ProbeUtils::networkOrderToIpString(from_addr.sin_addr.s_addr);

            // ����ICMP��Ӧ
            if (received >= static_cast<size_t>(sizeof(IpHeader) + 8)) {
                const IpHeader* ip_header = reinterpret_cast<const IpHeader*>(buffer);
                size_t ip_header_len = (ip_header->version_ihl & 0x0F) * 4;

                if (received >= static_cast<size_t>(ip_header_len + 8)) {
                    const IcmpPacket* icmp = reinterpret_cast<const IcmpPacket*>(buffer + ip_header_len);

                    // Time Exceeded��ʾ�м�·����
                    if (icmp->type == ICMP_TIME_EXCEEDED) {
                        result.type = "udp_time_exceeded";
                        result.success = true;
                        return true;
                    }

                    // Port Unreachable��ʾ����Ŀ��
                    if (icmp->type == ICMP_DEST_UNREACH && icmp->code == ICMP_PORT_UNREACH) {
                        result.type = "udp_port_unreachable";
                        result.success = true;
                        return true;
                    }
                }
            }
        }

        result.success = false;
        return false;
    }
}

// ==================== ͳһ̽��ӿ� ====================
namespace NetworkProbe {
    ProbeResult probe(const ProbeConfig& config) {
        ProbeResult result = {};
        result.sequence = config.sequence;

        // ����Ŀ���ַ
        std::string target_ip = config.target;
        if (!ProbeUtils::isValidIpAddress(target_ip)) {
            target_ip = ProbeUtils::resolveDomainName(target_ip);
            if (target_ip.empty()) {
                std::cerr << "[Probe] Failed to resolve target: " << config.target << std::endl;
                result.success = false;
                return result;
            }
        }

        if (config.protocol == "icmp") {
            socket_t sock = IcmpProbe::createSocket(config.ip_version, target_ip);
            if (sock == INVALID_SOCKET_VALUE) {
                result.success = false;
                return result;
            }

            if (IcmpProbe::sendProbe(sock, target_ip, config.ttl, config.sequence)) {
                IcmpProbe::receiveResponse(sock, result, config.timeout_ms, config.sequence);
            }

#ifdef _WIN32
            closesocket(sock);
#else
            close(sock);
#endif
        }
        else if (config.protocol == "tcp") {
          static neo::RefPtr<IRawPacketInterface> pInterface = NULL;
          if (pInterface == NULL) {
              pInterface = new WinpcapPacketInterface();
            }

            net::InetAddress target(target_ip.c_str(), config.dest_port);
            pInterface->initialise(target);

            packet::TCPIPHeader h;
            int dest_port = config.dest_port > 0 ? config.dest_port : 8080;
            if (TcpProbe::sendProbe(pInterface, h, target, pInterface->getSourceAddress(), config.ttl)) {
                TcpProbe::receiveResponse(pInterface, h, result, config.timeout_ms);
            }

#ifdef _WIN32
            //closesocket(sock);
            //delete pInterface;
#else
            close(sock);
#endif
        }
        else if (config.protocol == "udp") {
            socket_t udp_sock = UdpProbe::createSocket(config.ip_version);
            socket_t icmp_sock = IcmpProbe::createSocket(config.ip_version, target_ip);

            if (udp_sock == INVALID_SOCKET_VALUE || icmp_sock == INVALID_SOCKET_VALUE) {
                result.success = false;
                if (udp_sock != INVALID_SOCKET_VALUE) {
#ifdef _WIN32
                    closesocket(udp_sock);
#else
                    close(udp_sock);
#endif
                }
                if (icmp_sock != INVALID_SOCKET_VALUE) {
#ifdef _WIN32
                    closesocket(icmp_sock);
#else
                    close(icmp_sock);
#endif
                }
                return result;
            }

            int dest_port = config.dest_port > 0 ? config.dest_port : 33434;
            if (UdpProbe::sendProbe(udp_sock, target_ip, config.ttl, config.sequence, dest_port)) {
                UdpProbe::receiveResponse(icmp_sock, result, config.timeout_ms, config.sequence);
            }

#ifdef _WIN32
            closesocket(udp_sock);
            closesocket(icmp_sock);
#else
            close(udp_sock);
            close(icmp_sock);
#endif
        }

        return result;
    }

    std::vector<ProbeResult> traceroute(const std::string& target,
        const std::string& protocol,
        int max_ttl,
        int dest_port,
        int timeout_ms) {
        std::vector<ProbeResult> results;

        ProbeConfig config;
        config.target = target;
        config.protocol = protocol;
        config.ip_version = 4;
        config.timeout_ms = timeout_ms;
        config.dest_port = dest_port;

        for (int ttl = 1; ttl <= max_ttl; ++ttl) {
            config.ttl = ttl;
            config.sequence = ttl;

            ProbeResult result = probe(config);
            result.sequence = ttl;
            results.push_back(result);

            ProbeUtils::printProbeResult(result, config);

            // �������Ŀ�ֹ꣬ͣ̽��
            if (result.success && result.ip == target) {
                break;
            }

            // ���������γ�ʱ�������Ѿ������յ�
            if (ttl > 3 && !result.success) {
                int consecutive_timeouts = 0;
                for (int i = ttl - 1; i >= 1 && i >= ttl - 3; --i) {
                    if (i < static_cast<int>(results.size()) && !results[i].success) {
                        consecutive_timeouts++;
                    }
                }
                if (consecutive_timeouts >= 3) {
                    break;
                }
            }
        }

        return results;
    }

    void printResults(const std::vector<ProbeResult>& results) {
        std::cout << "\n=== Traceroute Results ===" << std::endl;
        std::cout << "Hop\tIP\t\tType\t\tLatency(ms)" << std::endl;
        std::cout << "---\t---\t\t----\t\t-----------" << std::endl;

        for (size_t i = 0; i < results.size(); ++i) {
            const auto& result = results[i];
            std::cout << (i + 1) << "\t";

            if (result.success) {
                std::cout << result.ip << "\t" << result.type << "\t" << result.latency_ms;
            }
            else {
                std::cout << "*\t\ttimeout\t\t-";
            }
            std::cout << std::endl;
        }
        std::cout << std::endl;
    }
}

// ==================== ����/��ʾ���� ====================
#ifdef MTR_TCP_ICMP_STANDALONE_TEST
int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cout << "Usage: " << argv[0] << " <target> [protocol] [max_ttl] [dest_port]" << std::endl;
        std::cout << "  target: IP address or hostname" << std::endl;
        std::cout << "  protocol: icmp, tcp, or udp (default: icmp)" << std::endl;
        std::cout << "  max_ttl: maximum TTL (default: 30)" << std::endl;
        std::cout << "  dest_port: destination port for TCP/UDP (default: 8080/33434)" << std::endl;
        return 1;
    }

    std::string target = argv[1];
    std::string protocol = (argc > 2) ? argv[2] : "icmp";
    int max_ttl = (argc > 3) ? std::stoi(argv[3]) : 30;
    int dest_port = (argc > 4) ? std::stoi(argv[4]) : 0;

    if (protocol != "icmp" && protocol != "tcp" && protocol != "udp") {
        std::cerr << "Invalid protocol. Use: icmp, tcp, or udp" << std::endl;
        return 1;
    }

    // ��ʼ������
    if (!ProbeUtils::initializeNetwork()) {
        std::cerr << "Failed to initialize network" << std::endl;
        return 1;
    }

    std::cout << "Starting traceroute to " << target
        << " using " << protocol << " protocol..." << std::endl;
    std::cout << "Note: RAW sockets require administrator/root privileges" << std::endl;
    std::cout << std::endl;

    // ִ��traceroute
    auto results = NetworkProbe::traceroute(target, protocol, max_ttl, dest_port, 1500);

    // ��ӡ���
    NetworkProbe::printResults(results);

    // ����
    ProbeUtils::cleanupNetwork();

    return 0;
}
#endif
