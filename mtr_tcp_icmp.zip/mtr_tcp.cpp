// mtr_tcp.cpp : ���ļ����� "main" ����������ִ�н��ڴ˴���ʼ��������
//
#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include "mtr_tcp_icmp.h"
void testStandaloneProbe() {



    try {
        std::cout << "\n========== Standalone Probe Test: ICMP/TCP/UDP̽�⹦�� ==========\n" << std::endl;

        // ��ʼ�������
        if (!ProbeUtils::initializeNetwork()) {
            std::cerr << "[Standalone] Failed to initialize network library" << std::endl;
            return;
        }
        std::cout << "[Standalone] Network library initialized successfully" << std::endl;

        //// ========== Test 1: ICMP����̽�� ==========
        //std::cout << "\n--- Test 1: ICMP Single Probe to 8.8.8.8 ---" << std::endl;
        //ProbeConfig icmp_config;
        //icmp_config.target = "8.8.8.8";
        //icmp_config.protocol = "icmp";
        //icmp_config.ttl = 20;
        //icmp_config.sequence = 1;
        //icmp_config.timeout_ms = 2000;
        //icmp_config.ip_version = 4;
        //icmp_config.dest_port = 0;

        //ProbeResult icmp_result = NetworkProbe::probe(icmp_config);
        //ProbeUtils::printProbeResult(icmp_result, icmp_config);

        //if (icmp_result.success) {
        //    std::cout << "  -> Success! IP: " << icmp_result.ip
        //        << ", Type: " << icmp_result.type
        //        << ", Latency: " << icmp_result.latency_ms << "ms" << std::endl;
        //}
        //else {
        //    std::cout << "  -> Failed or Timeout" << std::endl;
        //}

        //// ========== Test 2: ICMP Traceroute ==========
        //std::cout << "\n--- Test 2: ICMP Traceroute to 8.8.8.8 (max 10 hops) ---" << std::endl;
        //std::cout << "Note: RAW sockets require administrator/root privileges" << std::endl;
        //auto icmp_trace_results = NetworkProbe::traceroute("8.8.8.8", "icmp", 10, 0, 2000);
        //NetworkProbe::printResults(icmp_trace_results);

        //return;

        // ========== Test 3: TCP����̽�� ==========
        std::cout << "\n--- Test 3: TCP Single Probe to 8.8.8.8:80 ---" << std::endl;
        ProbeConfig tcp_config;
        tcp_config.target = "8.8.8.8";
        tcp_config.protocol = "tcp";
        tcp_config.ttl = 5;
        tcp_config.sequence = 1;
        tcp_config.timeout_ms = 6000;
        tcp_config.ip_version = 4;
        tcp_config.dest_port = 53;

        ProbeResult tcp_result = NetworkProbe::probe(tcp_config);
        ProbeUtils::printProbeResult(tcp_result, tcp_config);

        if (tcp_result.success) {
            std::cout << "  -> Success! IP: " << tcp_result.ip
                << ", Type: " << tcp_result.type
                << ", Latency: " << tcp_result.latency_ms << "ms" << std::endl;
        }
        else {
            std::cout << "  -> Failed or Timeout" << std::endl;
        }

        return;

        // ========== Test 4: TCP Traceroute ==========
        std::cout << "\n--- Test 4: TCP Traceroute to 8.8.8.8:80 (max 10 hops) ---" << std::endl;
        std::cout << "Note: RAW sockets require administrator/root privileges" << std::endl;
        auto tcp_trace_results = NetworkProbe::traceroute("8.8.8.8", "tcp", 10, 80, 2000);
        NetworkProbe::printResults(tcp_trace_results);

        // ========== Test 5: UDP����̽�� ==========
        std::cout << "\n--- Test 5: UDP Single Probe to 8.8.8.8:33434 ---" << std::endl;
        ProbeConfig udp_config;
        udp_config.target = "8.8.8.8";
        udp_config.protocol = "udp";
        udp_config.ttl = 5;
        udp_config.sequence = 1;
        udp_config.timeout_ms = 2000;
        udp_config.ip_version = 4;
        udp_config.dest_port = 33434;

        ProbeResult udp_result = NetworkProbe::probe(udp_config);
        ProbeUtils::printProbeResult(udp_result, udp_config);

        if (udp_result.success) {
            std::cout << "  -> Success! IP: " << udp_result.ip
                << ", Type: " << udp_result.type
                << ", Latency: " << udp_result.latency_ms << "ms" << std::endl;
        }
        else {
            std::cout << "  -> Failed or Timeout" << std::endl;
        }

        // ========== Test 6: UDP Traceroute ==========
        std::cout << "\n--- Test 6: UDP Traceroute to 8.8.8.8:33434 (max 10 hops) ---" << std::endl;
        std::cout << "Note: RAW sockets require administrator/root privileges" << std::endl;
        auto udp_trace_results = NetworkProbe::traceroute("8.8.8.8", "udp", 10, 33434, 2000);
        NetworkProbe::printResults(udp_trace_results);

        // ========== Test 7: ������������ ==========
        std::cout << "\n--- Test 7: Domain Name Resolution Test ---" << std::endl;
        std::string test_domain = "www.baidu.com";
        std::string resolved_ip = ProbeUtils::resolveDomainName(test_domain);
        if (!resolved_ip.empty()) {
            std::cout << "  -> " << test_domain << " resolved to: " << resolved_ip << std::endl;

            // �Խ�����IP����ICMP̽��
            ProbeConfig domain_config;
            domain_config.target = resolved_ip;
            domain_config.protocol = "icmp";
            domain_config.ttl = 5;
            domain_config.sequence = 1;
            domain_config.timeout_ms = 2000;
            domain_config.ip_version = 4;
            domain_config.dest_port = 0;

            ProbeResult domain_result = NetworkProbe::probe(domain_config);
            ProbeUtils::printProbeResult(domain_result, domain_config);
        }
        else {
            std::cout << "  -> Failed to resolve " << test_domain << std::endl;
        }

        // ���������
        ProbeUtils::cleanupNetwork();
        std::cout << "\n[Standalone] Network library cleaned up" << std::endl;
        std::cout << "\n========== Standalone Probe Test Completed ==========\n" << std::endl;

    }
    catch (const std::exception& e) {
        std::cerr << "[Standalone] Exception: " << e.what() << std::endl;
        ProbeUtils::cleanupNetwork();
    }
}


int main(int argc, char **argv)
{
    testStandaloneProbe();
}

